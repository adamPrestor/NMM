  %% neural oscillation
  settings.gammaHighWidth = 8; % 8.66 tbe - 70Hz
  settings.gammaWidth = 20; % 30Hz
  settings.betaWidth = 47;  % 46.62 tbe - 13Hz
  settings.alphaWidth = 76; % 75.75 tbe - 8Hz
  settings.thetaWidth = 152; % 151.51 tbe - 4Hz